export AWS_ACCESS_KEY_ID=AKIAIHRVQINWH4NBR4FQ
export AWS_SECRET_ACCESS_KEY=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

cloudera-director bootstrap-remote ./aws.simple.conf --lp.remote.username=admin --lp.remote.password=admin --lp.remote.hostAndPort=localhost:7189
