export AWS_ACCESS_KEY_ID=AKIAIFOHTMOVVTMWNFIQ
export AWS_SECRET_ACCESS_KEY=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

cloudera-director bootstrap-remote ./aws.simple.conf --lp.remote.username=admin --lp.remote.password=admin --lp.remote.hostAndPort=localhost:7189
